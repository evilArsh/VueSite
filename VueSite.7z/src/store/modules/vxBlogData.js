import maps from '../vxMaps'
const vxBlogData = {
  state: {
    //初始化 
    queryAfter: 0,
    number: 10
  },
  actions: {
    //取数据
    fetchBlogList({ commit, disPatch, state }) {

    }
  },
  mutations: {
  },
  getters: {
  }
};
export default vxBlogData;
