export default{
    'home':'#2c3e50',
    'blogMenu':'#2c3e50',
    'userHome':'#2c3e50',
    'blogEdit':'#34495e',
    'blogContent':'#2c3e50',
    'sign':'#2980b9',
    'campusTime':'#ff9900',
    'ignore_me_home':'rgba(215,183,147,0.5)'
}
